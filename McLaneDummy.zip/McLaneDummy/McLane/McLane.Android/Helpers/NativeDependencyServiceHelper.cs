﻿using System;
using Android.App;
using Android.Content;
using Android.Views.InputMethods;
using McLane.Droid.Helpers;
using McLane.Services;
using Plugin.CurrentActivity;

[assembly: Xamarin.Forms.Dependency(typeof(NativeDependencyServiceHelper))]
namespace McLane.Droid.Helpers
{
    public class NativeDependencyServiceHelper : INativeDependencyServices
    {
        public NativeDependencyServiceHelper()
        {
        }
        public void HideKeyboard()
        {
            var context = Android.App.Application.Context;
            var inputMethodManager = context.GetSystemService(Context.InputMethodService) as InputMethodManager;
            var activity = CrossCurrentActivity.Current.Activity;

            if (inputMethodManager != null && activity != null)// && context is Activity)
            {
                //var activity = context as Activity;
                var token = activity.CurrentFocus?.WindowToken;
                inputMethodManager.HideSoftInputFromWindow(token, HideSoftInputFlags.None);

                activity.Window.DecorView.ClearFocus();
            }
        }
    }
}

