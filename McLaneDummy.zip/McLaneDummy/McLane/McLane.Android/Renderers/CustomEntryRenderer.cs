﻿using System;
using Android.Content;
using McLane.Controls;
using McLane.Droid.Renderers;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

[assembly: ExportRenderer(typeof(CustomEntry), typeof(CustomEntryRenderer))]
namespace McLane.Droid.Renderers
{
    public class CustomEntryRenderer : EntryRenderer
    {
        public CustomEntryRenderer(Context context) : base(context)
        {
        }

        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);

            var view = (CustomEntry)Element;
            if (view != null && Control != null)
            {
                Control.SetBackgroundColor(global::Android.Graphics.Color.Argb(0, 0, 0, 0));

                //Control.SetPadding(5, Control.PaddingTop, 10, Control.PaddingBottom);
                //Control.SetPadding(5, 0, 10, Control.PaddingBottom);
                //Control.SetPadding(5, 12, 10, 0);

                Control.Ellipsize = Android.Text.TextUtils.TruncateAt.End;
                Control.SetSingleLine(true);
                Control.SetMaxLines(1);
            }
        }
    }
}

