﻿using System;
using McLane.iOS.Helpers;
using McLane.Services;
using UIKit;

[assembly: Xamarin.Forms.Dependency(typeof(NativeDependencyServiceHelper))]
namespace McLane.iOS.Helpers
{
    public class NativeDependencyServiceHelper : INativeDependencyServices
    {
        public NativeDependencyServiceHelper()
        {
        }
        public void HideKeyboard()
        {
            UIApplication.SharedApplication.KeyWindow.EndEditing(true);
        }
    }
}

