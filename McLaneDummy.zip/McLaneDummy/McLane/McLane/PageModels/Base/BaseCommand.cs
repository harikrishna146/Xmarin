﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using FreshMvvm;

namespace McLane.PageModels.Base
{
    public class BaseCommand : ICommand
    {
        public bool Succes
        {
            get
            {
                return this.successCommand;
            }
        }

        public BaseCommand(FreshBasePageModel vm, string message = null)
        {
            this.vmodel = vm;
            this._message = message;
            isExecuting = false;
        }

        #region ICommand implementation

#pragma warning disable 0067
        public event EventHandler CanExecuteChanged;
#pragma warning restore 0067


        public virtual bool CanExecute(object parameter)
        {
            return !isExecuting;
        }

        public virtual void Execute(object parameter)
        {
            isExecuting = true;
        }

        public virtual async Task ExecuteAsync(object parameter)
        {
            await Task.FromResult(0);
        }

        #endregion

        protected string _message;
        protected FreshBasePageModel vmodel;
        protected bool successCommand;
        protected bool isExecuting;
    }
}