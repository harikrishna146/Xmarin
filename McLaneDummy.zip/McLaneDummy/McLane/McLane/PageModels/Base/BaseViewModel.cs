﻿using System;
using FreshMvvm;
using McLane.Extensions;
using McLane.Services;
using Rg.Plugins.Popup.Services;
using Xamarin.Forms;

namespace McLane.PageModels
{
    public class BaseViewModel : FreshBasePageModel
    {
        public ContentPage BaseView { get; set; }
        protected readonly IAppUtility AppUtility;
        protected readonly CustomProxy CustomProxy;
        #region Properties

        public bool ShowBusyLoader { get; set; }

        bool _isBusy = false;
        public bool IsBusy
        {
            get { return _isBusy; }
            set
            {
                if (_isBusy != value)
                {
                    _isBusy = value;
                    RaisePropertyChanged();
                    HandleBusyLoader();
                }
            }
        }
        #endregion  
        public BaseViewModel()
        {
            ShowBusyLoader = true;
        }
        public BaseViewModel(IAppUtility appUtility, CustomProxy customProxy)
        {
            AppUtility = appUtility;
            CustomProxy = customProxy;
            ShowBusyLoader = true;
        }

        #region Methods
        internal async void HandleBusyLoader()
        {
            try
            {
                if (ShowBusyLoader)
                {
                    if (IsBusy)
                        await CoreMethods.PushPopupPageModel<LoadingPopupPageModel>();
                    else
                    {
                        if (PopupNavigation.Instance.PopupStack.Count > 0)
                            await Rg.Plugins.Popup.Services.PopupNavigation.Instance.PopAsync();
                    }

                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.Log(ex);
            }
        }
        #endregion
    }
}

