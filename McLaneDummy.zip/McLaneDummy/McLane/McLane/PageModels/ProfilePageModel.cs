﻿using System;
using McLane.Services;

namespace McLane.PageModels
{
    public class ProfilePageModel : BaseViewModel
    {
        public ProfilePageModel(IAppUtility appUtility, CustomProxy customProxy) : base(appUtility, customProxy)
        {

        }
    }
}

