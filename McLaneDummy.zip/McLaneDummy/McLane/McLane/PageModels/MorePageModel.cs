﻿using System;
using McLane.Services;

namespace McLane.PageModels
{
    public class MorePageModel : BaseViewModel
    {
        public MorePageModel(IAppUtility appUtility, CustomProxy customProxy) : base(appUtility, customProxy)
        {

        }
    }
}

