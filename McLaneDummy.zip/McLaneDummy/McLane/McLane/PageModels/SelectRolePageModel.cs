﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using FreshMvvm;
using McLane.Models.Enums;
using McLane.PageModels.Base;
using McLane.PageModels.VTS;
using McLane.Services;
using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.AndroidSpecific;

namespace McLane.PageModels
{
    public class SelectRolePageModel : BaseViewModel
    {
        #region Properties
        #endregion
        
        public SelectRolePageModel(IAppUtility appUtility, CustomProxy customProxy) : base(appUtility, customProxy)
        {
        }
        
        #region Commands
        public ICommand ChooseAppCommand { get { return new RelayCommandWithArgsAsync<string>(async (arg) => await ChooseApp(arg), this); } }
        #endregion

        #region Methods
        private async Task ChooseApp(string arg)
        {
            try
            {
                if (arg == AppRoleEnum.VTS.ToString())
                {
                    var tabbedNavigation = new FreshTabbedNavigationContainer()
                    {
                        BarTextColor = Color.White,
                        BarBackgroundColor = Color.White,
                    };
                    tabbedNavigation.BarBackgroundColor = (Color)App.Current.Resources["White"];
                    tabbedNavigation.BackgroundColor = (Color)App.Current.Resources["White"];
                    tabbedNavigation.SelectedTabColor = (Color)App.Current.Resources["AppRed"];
                    tabbedNavigation.UnselectedTabColor = (Color)App.Current.Resources["Black"];

                    //tabbedNavigation.On<Xamarin.Forms.PlatformConfiguration.Android>().SetBarItemColor((Color)Xamarin.Forms.Application.Current.Resources["Black"]);// Unselected image+text color
                    tabbedNavigation.UnselectedTabColor = (Color)Xamarin.Forms.Application.Current.Resources["Black"];

                    NavigationPage.SetBackButtonTitle(tabbedNavigation, string.Empty);
                    tabbedNavigation.On<Xamarin.Forms.PlatformConfiguration.Android>().SetToolbarPlacement(ToolbarPlacement.Bottom);
                    tabbedNavigation.AddTab<VtsDashboardPageModel>("Home", "pin_red.png");
                    tabbedNavigation.AddTab<MorePageModel>("Cart", "yyyy.png");
                    tabbedNavigation.AddTab<ProfilePageModel>("Profile", "yyyy.png");
                    tabbedNavigation.AddTab<MorePageModel>("More", "yyyy.png");

                    App.Current.MainPage = tabbedNavigation;
                }
                else
                {
                    await CoreMethods.PushPageModel<SelectGroupPageModel>(false);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.Log(ex);
            }
        }
        #endregion
    }
}