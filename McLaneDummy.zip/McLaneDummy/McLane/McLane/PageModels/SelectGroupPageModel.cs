﻿using System;
using System.Windows.Input;
using McLane.PageModels.Base;
using McLane.Services;

namespace McLane.PageModels
{
    public class SelectGroupPageModel : BaseViewModel
    {
        #region Properties
        #endregion
        public SelectGroupPageModel(IAppUtility appUtility, CustomProxy customProxy) : base(appUtility, customProxy)
        {
        }
        #region Commands
        public ICommand SelectGroupCommand
        {
            get
            {
                return new RelayCommandWithArgsAsync<object>(async (arg) =>
                {
                    var model = arg as string;
                    if (model != null)
                    {
                        await CoreMethods.PushPageModel<SelectStorePageModel>(false);
                    }
                }, this);
            }
        }
        #endregion
    }
}

