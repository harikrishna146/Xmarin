﻿using System;
namespace McLane.PageModels
{
    public class LoadingPopupPageModel : BaseViewModel
    {
        public LoadingPopupPageModel()
        {
        }
    }
}

