﻿using System;
using System.Windows.Input;
using McLane.Extensions;
using McLane.Models;
using Xamarin.Forms;

namespace McLane.PageModels
{
    public class AlertPopupPageModel : BaseViewModel
    {
        #region Properties
        private string _title;
        private string _message;
        public string Title
        {
            get { return _title; }
            set
            {
                _title = value;
                RaisePropertyChanged(nameof(Title));
            }
        }

        public string Message
        {
            get { return _message; }
            set
            {
                _message = value;
                RaisePropertyChanged(nameof(Message));
            }
        }

        private Color _popupBG = Color.FromHex("#99000000");
        public Color PopupBG
        {
            get { return _popupBG; }
            set
            {
                _popupBG = value;
                RaisePropertyChanged(nameof(PopupBG));
            }
        }

        private bool _isTransparentBG;
        public bool IsTransparentBG
        {
            get { return _isTransparentBG; }
            set
            {
                _isTransparentBG = value;
                RaisePropertyChanged(nameof(IsTransparentBG));
                if (IsTransparentBG)
                    PopupBG = Color.FromHex("#1A000000");
                else
                    PopupBG = Color.FromHex("#99000000");
            }
        }
        #endregion

        public override void Init(object initData)
        {
            base.Init(initData);
            try
            {
                var alert = initData as AlertModel;
                if (alert != null)
                {
                    Title = alert.Title;
                    Message = alert.Message;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.Log(ex);
            }
        }

        public ICommand ClosePopupCommand
        {
            get
            {
                return new Command(async () =>
                {
                    try
                    {
                        await CoreMethods.PopPopupPageModel();
                    }
                    catch (Exception ex)
                    {
                        ExceptionLogger.Log(ex);
                    }
                });
            }
        }
    }
}

