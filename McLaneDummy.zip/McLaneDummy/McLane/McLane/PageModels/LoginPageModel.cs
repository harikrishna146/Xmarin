﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using FreshMvvm;
using McLane.PageModels.Base;
using McLane.Services;
using McLane.Validations;
using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.AndroidSpecific;

namespace McLane.PageModels
{
    public class LoginPageModel : BaseViewModel
    {
        #region Properties
        ValidatableObject<string> _username = new ValidatableObject<string>();
        public ValidatableObject<string> Username
        {
            get { return _username; }
            set { _username = value; RaisePropertyChanged(); }
        }

        ValidatableObject<string> _password = new ValidatableObject<string>();
        public ValidatableObject<string> Password
        {
            get { return _password; }
            set { _password = value; RaisePropertyChanged(); }
        }
        #endregion
        public LoginPageModel(IAppUtility appUtility, CustomProxy customProxy) : base(appUtility, customProxy)
        {
            AddLoginValidation();
        }
        #region Commands
        public ICommand LoginCommand { get { return new RelayCommandWithArgsAsync<object>(async (arg) => await Login(), this); } }

        #endregion
        #region Methods
        private async Task Login()
        {
            try
            {
                if (Validate())
                {
                    IsBusy = true;
                    //Navigate to dashboard page after successfully login  
                    var page = FreshPageModelResolver.ResolvePageModel<SelectRolePageModel>();
                    var basicNavContainer = new FreshNavigationContainer(page)
                    {
                        BarTextColor = Color.White
                    };
                    await Task.Delay(500);//To check loader
                    IsBusy = false;
                    App.Current.MainPage = basicNavContainer;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.Log(ex);
            }
        }

        #region Validation Methods
        internal void AddLoginValidation()
        {
            try
            {
                _username.Validations.Add(new IsNotNullOrEmptyValidationRule<string> { ValidationMessage = "User ID is required" });
                _password.Validations.Add(new IsNotNullOrEmptyValidationRule<string>() { ValidationMessage = "Password is required" });
            }
            catch (Exception ex)
            {
                ExceptionLogger.Log(ex);
            }
        }
        internal void ClearLoginValidation()
        {
            try
            {
                Username = new ValidatableObject<string>();
                Password = new ValidatableObject<string>();
            }
            catch (Exception ex)
            {
                ExceptionLogger.Log(ex);
            }
        }
        internal Boolean Validate()
        {
            var usernameValidation = this.Username.Validate();
            var passwordValidation = this.Password.Validate();

            return usernameValidation && passwordValidation;
        }
        #endregion
        #endregion
    }
}

