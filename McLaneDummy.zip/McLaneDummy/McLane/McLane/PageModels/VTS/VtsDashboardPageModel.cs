﻿using System.Collections.ObjectModel;
using System.Reactive.Linq;

namespace McLane.PageModels.VTS
{
    public class VtsDashboardPageModel : BaseViewModel
    {
        public VtsDashboardPageModel()
        {
            CategoriesList = new ObservableCollection<string>()
            {
                "Candy",
                "Salty Snacks",
                "Dairy",
                "Sweet Snacks",
                "Cigaretee",
                "Food Services",
                "Party",
                "Home",
                "Baby",
            };
        }

        #region Properties

        private ObservableCollection<string> categoriesList;

        public ObservableCollection<string> CategoriesList
        {
            get { return categoriesList; }
            set 
            { 
                categoriesList = value;
                RaisePropertyChanged("CategoriesList");                
            }
        }


        #endregion
    }
}
