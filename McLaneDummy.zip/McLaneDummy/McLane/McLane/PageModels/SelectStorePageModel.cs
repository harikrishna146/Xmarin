﻿using System;
using System.Windows.Input;
using FreshMvvm;
using McLane.PageModels.Base;
using McLane.PageModels.VTS;
using McLane.Services;
using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.AndroidSpecific;

namespace McLane.PageModels
{
    public class SelectStorePageModel : BaseViewModel
    {
        #region Properties
        #endregion
        public SelectStorePageModel(IAppUtility appUtility, CustomProxy customProxy) : base(appUtility, customProxy)
        {
        }
        #region Commands
        public ICommand SelectStoreCommand
        {
            get
            {
                return new RelayCommandWithArgsAsync<object>(async (arg) =>
                {
                    var model = arg as string;
                    if (model != null)
                    {
                        var tabbedNavigation = new FreshTabbedNavigationContainer()
                        {
                            BarTextColor = Color.White,
                            BarBackgroundColor = Color.White,
                        };
                        tabbedNavigation.BarBackgroundColor = (Color)App.Current.Resources["White"];
                        tabbedNavigation.BackgroundColor = (Color)App.Current.Resources["White"];
                        tabbedNavigation.SelectedTabColor = (Color)App.Current.Resources["AppRed"];
                        tabbedNavigation.UnselectedTabColor = (Color)App.Current.Resources["Black"];
                        tabbedNavigation.On<Xamarin.Forms.PlatformConfiguration.Android>().SetBarItemColor((Color)App.Current.Resources["Black"]);// Unselected image+text color

                        NavigationPage.SetBackButtonTitle(tabbedNavigation, string.Empty);
                        tabbedNavigation.On<Xamarin.Forms.PlatformConfiguration.Android>().SetToolbarPlacement(ToolbarPlacement.Bottom);
                        tabbedNavigation.AddTab<VtsDashboardPageModel>("Home", "xy.png");
                        tabbedNavigation.AddTab<ProfilePageModel>("Orders", "yyyy.png");
                        tabbedNavigation.AddTab<MorePageModel>("Cart", "yyyy.png");
                        tabbedNavigation.AddTab<MorePageModel>("More", "yyyy.png");
                        App.Current.MainPage = tabbedNavigation;
                    }
                }, this);
            }
        }
        #endregion
    }
}

