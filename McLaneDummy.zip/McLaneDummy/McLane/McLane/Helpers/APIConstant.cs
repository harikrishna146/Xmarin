﻿using System;
using McLane.Models.Enums;
namespace McLane.Helpers
{
    public class APIConstant
    {
        public static AppEnvironmentEnum Envi = AppEnvironmentEnum.QA;

        public static string MainServerBaseURL
        {
            get
            {
                string url = "";
                switch (Envi)
                {
                    case AppEnvironmentEnum.QA:
                        url = "https://mclane.com";
                        break;
                    case AppEnvironmentEnum.Stage:
                        url = "https://mclane.com";
                        break;
                    case AppEnvironmentEnum.Production:
                        url = "https://mclane.com";
                        break;


                }
                return url;
            }

        }

        public static string ServerBaseURL
        {
            get
            {
                return string.Format("{0}", MainServerBaseURL);
            }
        }

        #region API
        #endregion
    }
}

