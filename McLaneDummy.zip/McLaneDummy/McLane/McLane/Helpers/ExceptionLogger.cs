﻿using System;
namespace McLane
{
    public class ExceptionLogger
    {
        public static void Log(Exception ex)
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("Exception Details :");
                System.Diagnostics.Debug.WriteLine("Error Message: {0}\n", ex.Message);
                System.Diagnostics.Debug.WriteLine("StackTrace: {0}\n", ex.StackTrace);
                System.Diagnostics.Debug.WriteLine("Inner Exception: {0}\n", ex.InnerException);
            }
            catch (Exception exc)
            {
                System.Diagnostics.Debug.WriteLine(exc.Message);
            }
        }
    }
}

