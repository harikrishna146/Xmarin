﻿using System;
using System.Text.RegularExpressions;

namespace McLane.Validations
{
    public class EmailValidationRule<T> : IValidationRule<T> where T : class
    {

        public string ValidationMessage { get; set; }

        public bool Validate(T value)
        {
            if (value == null) return false;

            var stringValue = value as String;
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            var match = regex.Match(stringValue);

            return match.Success;

        }

        public bool Validate(T value, T value1)
        {
            return false;
        }
    }
}

