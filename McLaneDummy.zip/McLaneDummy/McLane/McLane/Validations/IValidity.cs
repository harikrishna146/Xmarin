﻿using System;
namespace McLane.Validations
{
    public interface IValidity
    {
        bool IsValid { get; set; }
    }
}

