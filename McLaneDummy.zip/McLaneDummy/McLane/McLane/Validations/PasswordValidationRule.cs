﻿using System;
using System.Text.RegularExpressions;

namespace McLane.Validations
{
    public class PasswordValidationRule<T> : IValidationRule<T> where T : class
    {
        public string ValidationMessage { get; set; }

        public static Regex PasswordRegex = new Regex(@"^.*(?=.{8,16})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!*@#$%^&+=]).*$");

        public bool Validate(T value)
        {
            if (value == null) return false;

            var stringValue = value as String;
            //return (Regex.IsMatch(stringValue, PasswordRegex.ToString())) ? true : false;
            return IsValidPassword(stringValue);
        }

        public bool Validate(T value, T value1)
        {
            return false;
        }

        public static Func<string, bool> IsValidPassword = str =>
        {
            return (Regex.IsMatch(str, PasswordRegex.ToString())) ? true : false;
        };
    }
}

