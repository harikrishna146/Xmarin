﻿using System;
namespace McLane.Validations
{
    public class CompareValidationRule<T> : IValidationRule<T> where T : class
    {

        public string ValidationMessage { get; set; }

        public bool Validate(T value, T value1)
        {
            if (value == null) return false;

            var stringValue = value as String;
            var compareValue = value1 as String;
            return stringValue == compareValue;

        }

        public bool Validate(T value)
        {
            return false;
        }
    }
}

