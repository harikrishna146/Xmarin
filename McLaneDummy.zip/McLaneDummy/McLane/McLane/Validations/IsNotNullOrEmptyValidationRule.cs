﻿using System;
namespace McLane.Validations
{
    public class IsNotNullOrEmptyValidationRule<T> : IValidationRule<T> where T : class
    {
        public string ValidationMessage { get; set; }

        public bool Validate(T value)
        {
            if (value == null)
                return false;

            var stringValue = value as String;
            return !string.IsNullOrWhiteSpace(stringValue);
        }

        public bool Validate(T value, T value1)
        {
            return false;
        }
    }

    public class IsNotNullItemValidationRule<T> : IValidationRule<T> where T : class
    {
        public string ValidationMessage { get; set; }

        public bool Validate(T value)
        {
            if (value == null)
                return false;

            return true;
        }

        public bool Validate(T value, T value1)
        {
            return true;
        }
    }

    public class IsNotZeroValidationRule<T> : IValidationRule<T> where T : class
    {
        public string ValidationMessage { get; set; }

        public bool Validate(T value)
        {
            if (value == null)
                return false;

            int intValue = Convert.ToInt32(value);
            if (intValue <= 0)
                return false;
            return true;
        }

        public bool Validate(T value, T value1)
        {
            return true;
        }
    }
}

