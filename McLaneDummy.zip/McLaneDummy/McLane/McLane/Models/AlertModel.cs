﻿using System;
namespace McLane.Models
{
    public class AlertModel
    {
        public AlertModel()
        {
        }
        public string Title { get; set; }
        public string Message { get; set; }
    }
}

