﻿using System;
using System.ComponentModel;

namespace McLane.Models.Enums
{
    public enum AppRoleEnum
    {
        [Description("Virtual Trade Show")]
        VTS = 1,

        [Description("Smart Ordering / Hand Held")]
        SHH = 2
    }
}

