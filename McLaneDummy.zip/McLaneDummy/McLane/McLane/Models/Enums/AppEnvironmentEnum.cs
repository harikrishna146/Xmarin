﻿using System;
using System.ComponentModel;

namespace McLane.Models.Enums
{
    public enum AppEnvironmentEnum
    {
        [Description("QA")]
        QA = 1,

        [Description("Production")]
        Production = 2,

        [Description("Stage")]
        Stage = 3,
    }
}

