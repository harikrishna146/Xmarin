﻿using System;
namespace McLane.Models.Common
{
    public class BaseResponseModel
    {
        public bool invalidSession { get; set; }
        public bool successful { get; set; }
        public string message { get; set; }
    }
}

