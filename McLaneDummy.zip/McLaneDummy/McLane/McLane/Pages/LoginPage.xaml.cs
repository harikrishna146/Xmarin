﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace McLane.Pages
{
    public partial class LoginPage : ContentPage
    {
        public LoginPage()
        {
            InitializeComponent();
        }
    }
}

