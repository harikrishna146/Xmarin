﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace McLane.Pages
{
    public partial class SelectGroupPage : ContentPage
    {
        public SelectGroupPage()
        {
            InitializeComponent();
        }
    }
}

