﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace McLane.Pages
{
    public partial class ProfilePage : ContentPage
    {
        public ProfilePage()
        {
            InitializeComponent();
        }
    }
}

