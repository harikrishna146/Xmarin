﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace McLane.Extensions
{
    /// <summary>
    /// The Thickness Extension.
    /// Link : https://docs.microsoft.com/en-us/dotnet/api/xamarin.forms.xaml.imarkupextension?view=xamarin-forms
    /// </summary>
    [ContentProperty("EzyCornerRadius")]
    public class CornerRadiusExtension : IMarkupExtension
    {
        public string EzyCornerRadius { get; set; }
        public object ProvideValue(IServiceProvider serviceProvider)
        {
            ///<summary>
            /// if EzyCornerRadius is null return
            ///</summary>
            if (EzyCornerRadius == null)
                return EzyCornerRadius;
            ///<summary>
            /// if EzyCornerRadius has only one value
            ///</summary>
            if (!EzyCornerRadius.Contains("|"))
                return Device.Idiom == TargetIdiom.Phone ? new CornerRadius(Convert.ToDouble(EzyCornerRadius)) : new CornerRadius(Convert.ToDouble(EzyCornerRadius) * 2);
            ///<summary>
            /// if EzyThickness contains more than one value
            ///</summary>
            var SplitValue = EzyCornerRadius?.Split('|');
            switch (SplitValue.Length)
            {
                ///<summary>
                /// if EzyThickness contains only two value
                ///</summary>
                case 2:
                    {
                        var top = Convert.ToDouble(SplitValue?[0]);
                        var bottom = Convert.ToDouble(SplitValue?[1]);
                        switch (Device.Idiom)
                        {
                            case TargetIdiom.Phone:
                                return new CornerRadius(top, top, bottom, bottom);
                            case TargetIdiom.Tablet:
                                return new CornerRadius(top * 2, top * 2, bottom * 2, bottom * 2);
                            default:
                                throw new NotSupportedException();
                        }
                    }
                ///<summary>
                /// if EzyThickness contains only two value
                ///</summary>
                case 4:
                    {
                        var topLeft = Convert.ToDouble(SplitValue?[0]);
                        var topRight = Convert.ToDouble(SplitValue?[1]);
                        var bottomLeft = Convert.ToDouble(SplitValue?[2]);
                        var bottomRight = Convert.ToDouble(SplitValue?[3]);
                        switch (Device.Idiom)
                        {
                            case TargetIdiom.Phone:
                                return new CornerRadius(topLeft, topRight, bottomLeft, bottomRight);

                            case TargetIdiom.Tablet:
                                return new CornerRadius(topLeft * 2, topRight * 2, bottomLeft * 2, bottomRight * 2);
                            default:
                                throw new NotSupportedException();
                        }
                    }
                default:
                    throw new NotSupportedException();
            }
        }
    }
}
