﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace McLane.Extensions
{
    /// <summary>
    /// The Thickness Extension.
    /// Link : https://docs.microsoft.com/en-us/dotnet/api/xamarin.forms.xaml.imarkupextension?view=xamarin-forms
    /// </summary>
    [ContentProperty("EzyCornerRadiusFloat")]
    public class CornerRadiusFloatExtension : IMarkupExtension
    {
        public string EzyCornerRadiusFloat { get; set; }
        public object ProvideValue(IServiceProvider serviceProvider)
        {
            ///<summary>
            /// if EzyCornerRadiusFloat is null return
            ///</summary>
            if (EzyCornerRadiusFloat == null)
                return EzyCornerRadiusFloat;
            ///<summary>
            /// if EzyCornerRadiusFloat has only one value
            ///</summary>
            if (!EzyCornerRadiusFloat.Contains("|"))
                return Device.Idiom == TargetIdiom.Phone ? float.Parse(EzyCornerRadiusFloat) : float.Parse(EzyCornerRadiusFloat) * 2;
            return EzyCornerRadiusFloat;
        }
    }
}
