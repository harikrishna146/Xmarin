﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace McLane.Extensions
{
    /// <summary>
    /// The Thickness Extension.
    /// Link : https://docs.microsoft.com/en-us/dotnet/api/xamarin.forms.xaml.imarkupextension?view=xamarin-forms
    /// </summary>
    [ContentProperty("EzyCornerRadiusInt")]
    public class CornerRadiusIntExtension : IMarkupExtension
    {
        public string EzyCornerRadiusInt { get; set; }
        public object ProvideValue(IServiceProvider serviceProvider)
        {
            ///<summary>
            /// if EzyCornerRadiusInt is null return
            ///</summary>
            if (EzyCornerRadiusInt == null)
                return EzyCornerRadiusInt;
            ///<summary>
            /// if EzyCornerRadiusInt has only one value
            ///</summary>
            if (!EzyCornerRadiusInt.Contains("|"))
                return Device.Idiom == TargetIdiom.Phone ? int.Parse(EzyCornerRadiusInt) : int.Parse(EzyCornerRadiusInt) * 2;
            return EzyCornerRadiusInt;
        }
    }
}
