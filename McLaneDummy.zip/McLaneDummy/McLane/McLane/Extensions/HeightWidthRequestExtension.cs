﻿using System;
using Xamarin.Essentials;
using Xamarin.Forms.Xaml;
using Xamarin.Forms;

namespace McLane.Extensions
{
    /// <summary>
    /// The HeightRequest Extension.
    /// Link : https://docs.microsoft.com/en-us/dotnet/api/xamarin.forms.xaml.imarkupextension?view=xamarin-forms
    /// </summary>
    [ContentProperty("EzyHeightWidthRequest")]
    public class HeightWidthRequestExtension : IMarkupExtension
    {
        public double EzyHeightWidthRequest { get; set; }
        public object ProvideValue(IServiceProvider serviceProvider)
        {
            var height_dpi = DeviceDisplay.MainDisplayInfo.Height / DeviceDisplay.MainDisplayInfo.Density;
            switch (Device.Idiom)
            {
                case TargetIdiom.Phone:
                    return EzyHeightWidthRequest;
                case TargetIdiom.Tablet:
                    if (height_dpi >= 1000 && height_dpi <= 1100)
                    {
                        ///<summary>
                        /// iOS : ipad pro 9.7 (2048 (h) * 1536 (w) (2 density)) = 2048 /2 = 1024
                        ///</summary>
                        return EzyHeightWidthRequest * 1.25;
                    }
                    else if (height_dpi >= 1100 && height_dpi <= 1200)
                    {
                        ///<summary>
                        /// iOS : ipad pro 10.5 (2224 (h) * 1668 (w) (2 density)) = 2224 /2 = 1112
                        /// iOS : ipad pro 11 (2388 (h) * 1668 (w) (2 density)) = 2388 /2 = 1194
                        ///</summary>
                        return EzyHeightWidthRequest * 1.50;
                    }
                    else if (height_dpi >= 1200 && height_dpi <= 1300)
                    {
                        return EzyHeightWidthRequest * 1.75;
                    }
                    else if (height_dpi >= 1300 && height_dpi <= 1400)
                    {
                        ///<summary>
                        /// iOS : ipad pro 12.9 (2732 (h) * 2048 (w) (2 density)) = 2732 /2 = 1366
                        ///</summary>
                        return EzyHeightWidthRequest * 2;
                    }
                    else
                    {
                        return EzyHeightWidthRequest;
                    }
                default:
                    return EzyHeightWidthRequest;
            }
        }
    }
}


