﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace McLane.Extensions
{
    /// <summary>
    /// The Spacing Extension.
    /// Link : https://docs.microsoft.com/en-us/dotnet/api/xamarin.forms.xaml.imarkupextension?view=xamarin-forms
    /// </summary>
    [ContentProperty("EzySpacing")]
    public class SpacingExtension : IMarkupExtension
    {
        public double EzySpacing { get; set; }
        public object ProvideValue(IServiceProvider serviceProvider)
        {
            return Device.Idiom == TargetIdiom.Phone ? EzySpacing : EzySpacing * 2;
        }
    }
}

