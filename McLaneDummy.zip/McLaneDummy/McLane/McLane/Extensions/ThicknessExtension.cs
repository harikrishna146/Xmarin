﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace McLane.Extensions
{
    /// <summary>
    /// The Thickness Extension.
    /// Link : https://docs.microsoft.com/en-us/dotnet/api/xamarin.forms.xaml.imarkupextension?view=xamarin-forms
    /// </summary>
    [ContentProperty("EzyThickness")]
    public class ThicknessExtension : IMarkupExtension
    {
        public string EzyThickness { get; set; }
        public object ProvideValue(IServiceProvider serviceProvider)
        {
            ///<summary>
            /// if EzyThickness is null return
            ///</summary>
            if (EzyThickness == null)
                return EzyThickness;
            ///<summary>
            /// if EzyThickness has only one value
            ///</summary>
            if (!EzyThickness.Contains("|"))
                return Device.Idiom == TargetIdiom.Phone ? new Thickness(Convert.ToDouble(EzyThickness)) : new Thickness(Convert.ToDouble(EzyThickness) * 2);
            ///<summary>
            /// if EzyThickness contains more than one value
            ///</summary>
            var SplitValue = EzyThickness?.Split('|');
            switch (SplitValue.Length)
            {
                ///<summary>
                /// if EzyThickness contains only two value
                ///</summary>
                case 2:
                    {
                        var horizontal = Convert.ToDouble(SplitValue?[0]);
                        var vertical = Convert.ToDouble(SplitValue?[1]);
                        switch (Device.Idiom)
                        {
                            case TargetIdiom.Phone:
                                Thickness PhoneThickness = new Thickness();
                                PhoneThickness.Left = PhoneThickness.Right = horizontal;
                                PhoneThickness.Top = PhoneThickness.Bottom = vertical;
                                return PhoneThickness;

                            case TargetIdiom.Tablet:
                                Thickness TabletThickness = new Thickness();
                                TabletThickness.Left = TabletThickness.Right = horizontal * 2;
                                TabletThickness.Top = TabletThickness.Bottom = vertical * 2;
                                return TabletThickness;

                            default:
                                throw new NotSupportedException();
                        }
                    }
                ///<summary>
                /// if EzyThickness contains only two value
                ///</summary>
                case 4:
                    {
                        var left = Convert.ToDouble(SplitValue?[0]);
                        var top = Convert.ToDouble(SplitValue?[1]);
                        var right = Convert.ToDouble(SplitValue?[2]);
                        var bottom = Convert.ToDouble(SplitValue?[3]);
                        switch (Device.Idiom)
                        {
                            case TargetIdiom.Phone:
                                Thickness PhoneThickness = new Thickness
                                {
                                    Left = left,
                                    Top = top,
                                    Right = right,
                                    Bottom = bottom
                                };
                                return PhoneThickness;

                            case TargetIdiom.Tablet:
                                Thickness TabletThickness = new Thickness
                                {
                                    Left = left * 2,
                                    Top = top * 2,
                                    Right = right * 2,
                                    Bottom = bottom * 2
                                };
                                return TabletThickness;

                            default:
                                throw new NotSupportedException();
                        }
                    }
                default:
                    throw new NotSupportedException();
            }
        }
    }
}