﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using McLane.Extensions;
using McLane.Models;
using Xamarin.Essentials;

namespace McLane.Services
{
    public interface IAppUtility
    {
        string Username { get; set; }
    }
}

