﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using McLane.Models;
using McLane.Models.APIResult;
using McLane.Models.Common;
using MclaneXpress.Services;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace McLane.Services
{
    public class CustomProxy
    {
        private static HttpService _client;
        public static HttpService clinet
        {
            get
            {
                if (_client == null)
                {
                    _client = new HttpService();
                }
                return _client;
            }
        }
    }
}

