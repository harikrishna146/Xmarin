﻿using System;
namespace McLane.Services
{
    public interface INativeDependencyServices
    {
        void HideKeyboard();
    }
}

