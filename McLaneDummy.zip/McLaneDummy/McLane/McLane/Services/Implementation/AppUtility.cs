﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using McLane.Extensions;
using McLane.Models;
using Xamarin.Essentials;

namespace McLane.Services.Implementation
{
    public class AppUtility : IAppUtility
    {
        public AppUtility()
        {
        }

        public string Username { get; set; }
    }
}

