﻿using System;
using McLane.Services;
using Xamarin.Forms;

namespace MclaneXpress.Services.Implementation
{
    public class NativeDependencyServices
    {
        static readonly Lazy<INativeDependencyServices> _instanceHolder =
                new Lazy<INativeDependencyServices>(() => GetInstance());


        static INativeDependencyServices GetInstance()
        {
            return DependencyService.Get<INativeDependencyServices>();
        }

        public static INativeDependencyServices Instance => _instanceHolder.Value;
    }
}

