﻿using System;
using System.Collections;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace McLane.Converters
{
    public class InverseBooleanConverter : IValueConverter, IMarkupExtension
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value != null)
            {
                try
                {
                    var flag = (bool)value;

                    return !flag;
                }
                catch (Exception ex)
                {
                    ExceptionLogger.Log(ex);
                }
            }

            return false;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value;
        }

        public object ProvideValue(IServiceProvider serviceProvider)
        {
            return this;
        }
    }
}

