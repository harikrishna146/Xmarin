﻿using FreshMvvm;
using McLane.PageModels;
using McLane.PageModels.VTS;
using McLane.Services;
using McLane.Services.Implementation;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using Microsoft.AppCenter;
using Xamarin.Forms;

namespace McLane
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
            McLane.Controls.Shades.Initializer.Initialize(loggerEnable: false);
            FreshIOC.Container.Register<IAppUtility, AppUtility>().AsSingleton();
            FreshIOC.Container.Register<CustomProxy>(new CustomProxy());
            // To set MainPage for the Application
            var page = FreshPageModelResolver.ResolvePageModel<VtsDashboardPageModel>();
            var basicNavContainer = new FreshNavigationContainer(page)
            {
                BarTextColor = Color.White
            };
            MainPage = basicNavContainer;
        }

        protected override void OnStart()
        {
            AppCenter.Start("android={6327c046-7b85-425b-803c-5fb51646924f};", typeof(Analytics), typeof(Crashes));
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}

