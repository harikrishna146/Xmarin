﻿using System;
using Xamarin.Forms;

namespace McLane.Controls
{
    public class CustomEditor : Editor
    {
        public CustomEditor()
        {
            this.TextChanged += OnTextChanged_Grow;
        }

        private void OnTextChanged_Grow(Object sender, TextChangedEventArgs e)
        {
            this.InvalidateMeasure();
        }

    }
}

