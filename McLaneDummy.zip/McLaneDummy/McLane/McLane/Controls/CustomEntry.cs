﻿using System;
using Xamarin.Forms;

namespace McLane.Controls
{
    public class CustomEntry : Entry
    {
        public CustomEntry()
        {
        }
    }
}

